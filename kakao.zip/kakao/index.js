//const express = require('./node_modules/express/lib/express.js');
const express = require('express');
//const app = express();
//const logger = require('morgan');
//const bodyParser = require('body-parser');

const apiRouter = express.Router();

//const mysql = require('./node_modules/mysql/lib/mysql.js');
const mysql = require('mysql');
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "qngmd@)!!",
  database: "retreat",
  charset: "utf8mb4"
});
/*
app.use(logger('dev', {}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));
 */

apiRouter.post('/retr_barcode', function(req, res){
const action = JSON.parse(JSON.stringify(req.action));
const user_info = JSON.parse(JSON.stringify(req.userRequest));
const u_friend_key = user_info.user.properties.plusfriendUserKey;
const u_id = "";
var sql = 'SELECT * FROM personal WHERE kyogu = ? && group = ? && gisu = ? && name = ? ';
con.query(sql, [u_kyogu,u_group,u_gisu,u_name], function (err,result){
          if (err) throw err;
          u_id = u_id.concat(result['id']);
    });
var bar_url = "https://mscollege.or.kr/kakao/barcode/barcode_image/";
    bar_url = bar_url.concat(u_id,".png");
const desc = "";
      
const resBody = {
      "version": "2.0",
      "template": {
        "outputs": [
          {
            "basicCard": {
              "title": "모바일 바코드",
              "description": u_name.concat("의 바코드입니다"),
              "thumbnail": {
                "imageUrl": bar_url
              },
              "buttons": [
                {
                  "action":  "webLink",
                  "label": "확대하기",
                  "webLinkUrl": bar_url
                }
              ]
            }
          }
        ]
      }
    }
//    console.log(resBody);
               
    res.status(200).send(resBody);
})

